# [![back](https://cdn.discordapp.com/emojis/887168885747511396?size=32)]({PREVIOUS_PAGE_LINK}) Server emoji

###### Add up to 50 custom emojis that anyone can use in this server. Animated GIF emojis may be used by members with Discord Nitro. Emoji names must be at least 2 characters long and can only contain alphanumeric characters and underscores. Emoji must be under 256kb in size.



###### EMOJI - {#} SLOT(S) AVAILABLE
| Emoji | Alias | Uploaded by |
| :----: | :--- | :----: |
| ![{EMOJI_NAME}](https://cdn.discordapp.com/emojis/{ID}.png?size=32) | `:{ALIAS}:` | [{UPLOADER}]({UPLOADERS_SERVER_INVITE_LINK})