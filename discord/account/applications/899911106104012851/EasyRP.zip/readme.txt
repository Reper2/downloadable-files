EasyRP (Custom Discord Rich Presence) https://github.com/Pizzabelly/EasyRP
1. First you need to register a Rich Presence application with discord
     - Go here https://discordapp.com/developers/applications/me
     - Make a new application **The name of the app will be the main name for the rich presence**
     - Enable rich presence for your app and add some assets
2 Download the latest release of EasyRP from here https://github.com/Pizzabelly/EasyRP/releases 
3 Edit the config file with the information from your newly registered app
4 Run easyrp (it should open a cmd window)
    - It *should* report errors from your config file (if there are any)
5 Discord should show the game on your profile
	- if not, add the exe as a game on discord and the file path should change to your presence

You can edit the config any time while the program is running to change the presence (make sure to save the file)
